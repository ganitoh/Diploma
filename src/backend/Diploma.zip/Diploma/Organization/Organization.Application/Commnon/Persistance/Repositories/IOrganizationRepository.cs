﻿using Common.Application.Persistance;

namespace Organization.Application.Commnon.Persistance.Repositories;

public interface IOrganizationRepository : IRepository<Organization.Domain.Models.Organization> { }